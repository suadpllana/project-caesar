#!/bin/bash
# Verifier entry point. Runs in a SEPARATE container built from tests/Dockerfile, which
# owns /tests (this script is baked in at build time, not copied at run time).
#
# What this container can see of the agent's work: exactly the paths declared in
# `artifacts` in task.toml, re-materialized at their ORIGINAL absolute paths
# (the agent's /app/output.json is read here as /app/output.json). Nothing else.
#
# Contract, which must not change:
#   - Write exactly `0` or `1` to /logs/verifier/reward.txt
#   - Emit a pytest CTRF report to /logs/verifier/ctrf.json
#
# Keep every Python version pinned with ==. Never version-pin apt packages.

apt-get update
apt-get install -y curl
rm -rf /var/lib/apt/lists/*

curl -LsSf https://astral.sh/uv/0.9.7/install.sh | sh

source $HOME/.local/bin/env

uvx \
  --with pytest==9.1.1 \
  --with pytest-json-ctrf==0.5.2 \
  pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA

if [ $? -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
