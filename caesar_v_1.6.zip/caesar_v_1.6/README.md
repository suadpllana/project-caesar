# Frontier Bench Task Authoring

Bring a hard problem from your own work. Your AI assistant turns it into a benchmark task and does
the engineering.

---

## Start

1. Check Docker is running: `docker run --rm hello-world`
2. Open this folder in your AI assistant.
3. Paste **[SETUP.md](SETUP.md)** as your first message. It gets everything ready.
4. Then say: *"I want to author a task. Here's my idea…"*

From there your assistant takes over. It will interview you about the idea, build the environment,
write the reference solution and the automatic grader, try to break its own grader, test everything,
and package the submission. Your part is answering its questions and making the calls it brings to
you.

---

## Two things that stay yours

**The idea.** Real work you have actually done — the kind that takes an expert hours to days. If a
strong AI could finish it in twenty minutes, it will not be accepted. Difficulty has to come from
the work being genuinely hard, never from leaving things out or wording them vaguely.

**The words of the instruction.** You write the task description, with your assistant helping. It
tells you exactly what has to be covered, you describe the task the way you would brief a new
colleague, and it tidies your wording, suggests a line where you are stuck, and tells you what is
still missing. Your words stay in it and you approve every sentence. Minutes, not an afternoon.

---

That is everything you need. The rules, the full workflow, and the setup details live in
[AGENTS.md](AGENTS.md) and [docs/RULES.md](docs/RULES.md) for your assistant to follow.
You do not need to read them.
