`/app` is the container our services are wired through. Registrations name a
lifetime, scopes open and close around a unit of work, and when a scope closes
the container tears down whatever belongs to it. We rewrote the ownership and
teardown decisions last cycle and it has been wrong since.

Run `/app/run_wire.py` on `/app/cases/wide.txt`. The third line back reads
`torn pool 1 app`, and that line should not exist: `pool` was pulled in
underneath `app`, which is a singleton and outlives every scope in that
stream, so when scope 1 closed the container reached inside a live
singleton and disposed of a dependency it is still holding, while `app`
itself has not been torn down at all and will not be. There are seven more
case files in `/app/cases`. None of them comes out right either.

`/app/wire/own.py`, `/app/wire/pin.py`, `/app/wire/hold.py`, `/app/wire/gate.py`,
`/app/wire/tear.py`, `/app/wire/shut.py` and `/app/wire/plan.py` are yours to change. Some of them
are right. `/app/wire/core.py`, `/app/wire/reg.py` and `/app/wire/scope.py`
are the container itself and you may not touch them. Read them anyway. They
already settle things the editable files have to agree with.

We grade the dump, line for line, in the order it comes out. A teardown is
`torn`, then the registration name, then the scope that owned the instance,
then the name we were asked for when it came into being, which for anything
pulled in underneath something else is the name at the top of that
resolution and not the dependency's immediate parent; a declined
resolution is `refused`, then the name, then the scope we were in. Those two
words are the only record kinds we write and we match them exactly.

Some ground rules, because several of them are not what you would do
elsewhere.

An instance ordinarily belongs to the scope the work was charged to. A
singleton is built once, is owned by the root, and every new instance it
pulls in through dependencies or wrapping belongs to the root along with
it, however deep the chain runs and whatever lifetime or mark those
dependencies declare. This overrides marks. A previously cached instance
keeps its original owner and cause when another resolution reuses it.
Scoped reuse is keyed by registration and build scope, even when a mark
assigns teardown to another scope.

Within a scope, teardown runs in reverse allocation order. Allocation is
when the core reserves an instance number, before it builds dependencies
or wrapped registrations; the completion list is recorded later. Closing
a scope tears down nothing an ancestor owns. The root never closes.

A registration can carry a mark. Outside a singleton's pull-in chain, its
owner is the nearest scope in reach carrying that mark, with root as the
fallback if none matches. Reach starts at the charged scope and extends
through its ancestors. A mark changes only that instance's teardown owner;
its dependencies keep their own ownership rules and its build scope stays
the same. Wrapping follows the same allocation and ownership rules as a
dependency. A registration can declare a parting call, a name we resolve
as the instance is torn down, charged to the scope outside the one that is
closing. Nothing may be built into the closing scope any more. Each
parting call runs immediately after its instance's torn record.

Admission is checked once for the requested name on a resolve, invoke or
parting call. A requested singleton is refused if it can reach a scoped
registration through dependencies or wrapping, however deep. A requested
marked name is refused if no scope in reach carries its mark. These two
checks are not repeated for names pulled in underneath the request. Any
dependency or wrapping cycle reachable from the requested name refuses
the request. A refusal builds nothing at all. We also refuse a close with
no scope open and an invoke with no token from an earlier successful holder
resolution. Each is a single refused record. All names used in the streams
are registered; factory declarations are not dependency edges.

A scope that closes owning nothing prints nothing at all. A refusal is written
at the point we declined it and never held back to the end, so the dump for a
stream that mixes the two reads in the order the two kinds actually happened.

A component can hold a factory for another registration, and it can invoke
that factory inside a scope that was opened after the holder itself was
built. Factory work uses the build scope stored in its token, including for
a transient holder. Every successful explicit resolution of a holder
replaces the tokens for its declared factories with tokens bound to that
resolution's scope, even if the holder was cached or has a different
teardown owner. The latest token for a factory name is the one invoked.
Closing its scope does not revoke it or move its build scope; ordinary
admission still applies, and a dead scope has no ancestors in reach.

Scope labels and refusal locations follow the stack in the frozen code.
On a refused invoke the record names the scope where the invoke was
attempted, while a refused parting call names its landing scope. Internal
instance numbers are not printed, but their allocation order governs the
dump. All records retain their order across scope closes and refusals.

The dump has to describe the run that produced it.

You have 14400 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
