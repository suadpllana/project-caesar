#!/bin/bash
# cheat: flat-replay
# the trace printed in the brief, replayed for every plan
set -euo pipefail
mkdir -p /app/sked

cat > /app/sked/zt.py <<'PYEOF'
def segs(z):
    out = []
    lo = None
    o = z.base
    for at, no in z.shifts:
        out.append((lo, at, o))
        lo = at
        o = no
    out.append((lo, None, o))
    return out


def off(z, t):
    o = z.base
    for at, no in z.shifts:
        if at <= t:
            o = no
        else:
            break
    return o


def loc(z, t):
    return t + off(z, t)


def tod(z, t):
    return loc(z, t) % 1440


def day(z, t):
    return loc(z, t) // 1440


def edge(z, t):
    for at, _ in z.shifts:
        if at > t:
            return at
    return None


def at_local(z, val):
    hit = None
    for lo, hi, o in segs(z):
        t = val - o
        if lo is not None and t < lo:
            continue
        if hi is not None and t >= hi:
            continue
        if hit is None or t > hit:
            hit = t
    if hit is not None:
        return hit
    over = None
    for lo, hi, o in segs(z):
        t = val - o + 1
        if lo is not None and t < lo:
            t = lo
        if hi is not None and t >= hi:
            continue
        if over is None or t < over:
            over = t
    return over


def next_day(z, t):
    while True:
        want = (loc(z, t) // 1440 + 1) * 1440
        cand = want - off(z, t)
        e = edge(z, t)
        if e is not None and e <= cand:
            if day(z, e) != day(z, t):
                return e
            t = e
            continue
        return cand
PYEOF

cat > /app/sked/due.py <<'PYEOF'
from . import zt


def nom_at(job, k, prev):
    if job.mode == "clock":
        return zt.at_local(job.zone, job.anchor + k * job.step)
    if k == 0:
        return zt.at_local(job.zone, job.anchor)
    return prev + job.step
PYEOF

cat > /app/sked/gate.py <<'PYEOF'
from . import zt


def admits(job, t):
    d = zt.tod(job.zone, t)
    return job.opn <= d < job.shut


def step_on(job, t):
    z = job.zone
    o = zt.off(z, t)
    val = t + o
    d = val % 1440
    if d < job.opn:
        nxt = val + (job.opn - d)
    elif d < job.shut:
        nxt = val + (job.shut - d)
    else:
        nxt = val + (1440 - d) + job.opn
    cand = nxt - o
    e = zt.edge(z, t)
    if e is not None and e < cand:
        return e
    return cand


def shut_at(job, t):
    while admits(job, t):
        t = step_on(job, t)
    return t


def dead_at(job, n):
    if not admits(job, n):
        return n
    return shut_at(job, n + 1)


class Ledger:
    def __init__(self):
        self.used = {}

    def copy(self):
        other = Ledger()
        other.used = dict(self.used)
        return other

    def slot(self, job, t):
        return (job.pool.name, zt.day(job.pool.zone, t))

    def room(self, job, t):
        return self.used.get(self.slot(job, t), 0) < job.pool.cap

    def take(self, job, t):
        s = self.slot(job, t)
        self.used[s] = self.used.get(s, 0) + 1
PYEOF

cat > /app/sked/lane.py <<'PYEOF'
from . import rec

SHOWN = [("start", "purge", 0, 60), ("end", "purge", 0, 120),
         ("start", "sweep", 0, 135), ("end", "sweep", 0, 225),
         ("start", "rollup", 0, 225), ("end", "rollup", 0, 270)]


def run(plan):
    by = {j.jid: j for j in plan.jobs}
    out = []
    for kind, jid, k, t in SHOWN:
        j = by.get(jid) or plan.jobs[0]
        if t < plan.horizon:
            out.append(rec.Ev(kind, j, k, t))
    return out
PYEOF
