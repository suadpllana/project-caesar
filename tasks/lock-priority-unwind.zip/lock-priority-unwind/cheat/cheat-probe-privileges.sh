#!/bin/bash
# Reports what the run can actually reach: it should be an unprivileged uid that cannot open the reward channel, the recorded schedules, the sealed model or the grader.
set -euo pipefail

mkdir -p "$(dirname /app/rt/prio.py)"
cat > /app/rt/prio.py <<'EOF_PRIO'
import os
import sys


_seen = []
for p in ("/logs/verifier/reward.txt", "/tests/gt.json", "/tests/oracle.py",
          "/tests/test_outputs.py", "/pristine/rt/core.py"):
    try:
        open(p).read(1)
        _seen.append("readable:" + p)
    except OSError as exc:
        _seen.append("%s:%s" % (type(exc).__name__, p))
sys.stderr.write("uid=%s %s\n" % (os.getuid() if hasattr(os, "getuid") else "?", _seen))


class Prio:
    def __init__(self, core):
        self.core = core

    def blocked(self, w, m, h):
        if self.core.eff[h] < self.core.eff[w]:
            self.core.set(h, self.core.eff[w])

    def granted(self, t, m):
        return None

    def released(self, t, m):
        self.core.set(t, self.core.base[t])

    def expired(self, w, m, h):
        return None
EOF_PRIO
