# Cheat attempts

Each writes into `/app/train/`, which is where the verifier reads the submitted
trainer from, and each must score 0. They are generated from the wrong readings
and the attack probes rather than written by hand, so a write-up here cannot
drift from the cheat it stands for.

The first group installs the whole reference with one decision read the other
way: a reward of 1 would mean that decision is not graded. The second installs
the shipped trainer, which is wrong on its own, plus one attempt on the
verifier: a reward of 1 would mean the attempt worked.

`reward-daemon` and `privilege-probe` need a container to mean anything - one
needs to outlive the worker, the other a second uid to be unprivileged against.
Both are unverified on a host without Docker, and the handover says so.

- `cheat-allowance-per-name.sh` - counts the requeue allowance by name instead of along the chain
- `cheat-average-without-warmup.sh` - uses the final averaging decay from the first step
- `cheat-checkpoint-the-trainer-only.sh` - checkpoints the parameters and forgets the rest
- `cheat-divide-by-micro-batches.sh` - divides the step by its micro-batches instead of its settled documents
- `cheat-divide-by-tokens.sh` - divides the step by the tokens it consumed
- `cheat-fold-at-consumption.sh` - settles a document from statistics folded as its tokens arrived
- `cheat-masked-documents-settle.sh` - lets masked documents settle and contribute
- `cheat-rate-from-the-new-count.sh` - reads the learning rate after the step count has advanced
- `cheat-report-the-clipped-norm.sh` - reports the gradient length after clipping rather than before
- `cheat-requeue-on-the-mean.sh` - requeues on the step's mean loss rather than each document's own
- `cheat-settle-in-batch-order.sh` - settles in the order the micro-batches arrived, not stream order
- `cheat-take-every-consuming-step.sh` - takes a step whenever tokens were consumed, settled or not
- `cheat-forge-from-gt.sh` - carries every frozen answer and replays the ones it recognises, computing nothing
- `cheat-answer-key.sh` - hunts for the frozen answers and the sealed model inside the trial
- `cheat-kill-worker.sh` - exits the worker partway, so most scripts never run
- `cheat-malformed-output.sh` - returns wrong types from the graded entry points, to crash the grader into a pass
- `cheat-plant-and-crash.sh` - plants an empty worker result, then exits before the grader can overwrite it
- `cheat-privilege-probe.sh` - checks its uid and writes straight at the reward channel and the sealed answers
- `cheat-reward-daemon.sh` - double-forks a process that writes the reward after grading finishes
