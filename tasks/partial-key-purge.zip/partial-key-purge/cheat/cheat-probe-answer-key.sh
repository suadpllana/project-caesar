#!/bin/bash
# reads the sealed answers and the sealed model from inside the submitted code
set -euo pipefail

cat > /app/db/match.py <<'PYEOF'
def form(ref, vals):
    got = tuple(i for i, c in enumerate(ref.cols) if vals[c] is not None)
    if len(got) < len(ref.cols):
        return None
    return got


def ups(store, ref, vals):
    if not form(ref, vals):
        return []
    want = [vals[c] for c in ref.cols]
    kt = ref.key.tab.name
    out = []
    for pid in store.ids(kt):
        pv = store.get(kt, pid)
        if [pv[c] for c in ref.key.cols] == want:
            out.append(pid)
    return out


def downs(store, ref, pvals):
    want = [pvals[c] for c in ref.key.cols]
    ct = ref.tab.name
    out = []
    for cid in store.ids(ct):
        cv = store.get(ct, cid)
        if form(ref, cv) and [cv[c] for c in ref.cols] == want:
            out.append(cid)
    return out
PYEOF

cat > /app/db/drop.py <<'PYEOF'
import copy

from db import clear, hold, match


def delete(store, tab, ids):
    keep = copy.deepcopy(store.data)
    log = {"gone": [], "wiped": set(), "bad": []}
    for rid in ids:
        if store.has(tab, rid):
            cut(store, tab, rid, log)
    bad = hold.check(store, log)
    if bad:
        store.data = keep
        return ("refused",) + bad
    return ("ok", len(log["gone"]), len(log["wiped"]))


def cut(store, tab, rid, log):
    vals = store.get(tab, rid)
    store.drop(tab, rid)
    log["gone"].append((tab, rid))
    for ref in store.tabs[tab].used:
        ct = ref.tab.name
        for c in match.downs(store, ref, vals):
            if not store.has(ct, c) or match.ups(store, ref, store.get(ct, c)):
                continue
            if ref.act == "cascade":
                cut(store, ct, c, log)
            elif ref.act == "setnull":
                clear.wipe(store, ref, ct, c)
                log["wiped"].add((ct, c))
            else:
                log["bad"].append((ref.name, c))
PYEOF

cat > /app/db/clear.py <<'PYEOF'
def wipe(store, ref, tab, rid):
    for c in ref.cols:
        store.put(tab, rid, c, None)
PYEOF

cat > /app/db/hold.py <<'PYEOF'
from db import match


def check(store, log):
    if log["bad"]:
        return log["bad"][0]
    for tab, rid in sorted(log["wiped"]):
        vals = store.get(tab, rid)
        for ref in store.tabs[tab].refs:
            if match.form(ref, vals) and not match.ups(store, ref, vals):
                return (ref.name, rid)
    return None
PYEOF

cat > /app/db/audit.py <<'PYEOF'
import json
import os
import sys


def _note(what):
    try:
        with open("/work/run/probe.log", "a") as f:
            f.write("%s\n" % what)
    except Exception:
        pass


def _forge():
    name = os.path.basename(sys.argv[1])[:-4]
    for path in ("/tests/seal/expected.json", "/tests/seal/gt.json"):
        try:
            with open(path) as f:
                data = json.load(f)
        except Exception as exc:
            _note("DENIED %s %s" % (path, type(exc).__name__))
            continue
        ans = data.get(name)
        if isinstance(ans, dict):
            ans = ans.get("want")
        if ans is not None:
            _note("FORGED %s from %s" % (name, path))
            sys.stdout.write("".join(line + "\n" for line in ans))
            sys.stdout.flush()
            os._exit(0)
    try:
        sys.path.insert(0, "/tests/seal")
        import model
        with open(sys.argv[1]) as f:
            ans = model.expect(f.read())
        _note("FORGED %s from the model" % name)
        sys.stdout.write("".join(line + "\n" for line in ans))
        sys.stdout.flush()
        os._exit(0)
    except Exception as exc:
        _note("DENIED model %s" % type(exc).__name__)


_forge()


import copy

from db import drop, rows


def audit(store):
    out = []
    for tab in store.script.tabs:
        for rid in store.ids(tab.name):
            twin = rows.Store(store.script)
            twin.data = copy.deepcopy(store.data)
            res = drop.delete(twin, tab.name, [rid])
            if res[0] == "ok":
                out.append((tab.name, rid, res[1], res[2], False))
            else:
                out.append((tab.name, rid, 0, 0, True))
    return out
PYEOF
