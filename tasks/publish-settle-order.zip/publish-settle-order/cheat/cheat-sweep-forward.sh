#!/bin/bash
# takes the first unwanted unit in publication order rather than the last
set -euo pipefail

cat > /app/link/walk.py <<'PYEOF'
from link import drop, pick, site, view, want
from reg import hold, order, say, tab


def bring(h, name, wide, out):
    r = tab.get(h, name)
    if r.live:
        was = view.den(h, r)
        if wide and was is not None:
            view.open_up(h, r)
            pick.moved(h, r, was)
    else:
        _up(h, r, None if wide else view.fresh(h), set(), out)
    hold.take(h, name)


def _up(h, r, den, busy, out):
    busy.add(r.name)
    for other, _kind in r.needs:
        dr = tab.get(h, other)
        if dr.live or dr.name in busy:
            continue
        _up(h, dr, den, busy, out)
    h.tick = getattr(h, "tick", 0) + 1
    r.at = h.tick
    r.live = True
    r.uses = {}
    view.seal(h, r, den)
    order.add(h, r)
    pick.joined(h, r)
    want.joined(h, r)
    if not want.wanted(h, r):
        drop.note(h, r)
    say.up(out, r.name)
    for sym in r.boots:
        site.reach(h, r, sym, out)
    busy.discard(r.name)
PYEOF

cat > /app/link/view.py <<'PYEOF'
def _dens(h):
    d = getattr(h, "dens", None)
    if d is None:
        d = h.dens = {}
    return d


def fresh(h):
    h.scopes = getattr(h, "scopes", 0) + 1
    return h.scopes


def seal(h, r, den):
    _dens(h)[r.name] = den


def open_up(h, r):
    _dens(h)[r.name] = None


def den(h, r):
    return _dens(h).get(r.name)


def keys(h, caller):
    mine = den(h, caller)
    return (None,) if mine is None else (None, mine)
PYEOF

cat > /app/link/pick.py <<'PYEOF'
from link import view


def _idx(h):
    i = getattr(h, "idx", None)
    if i is None:
        i = h.idx = {}
    return i


def _syms(r):
    return dict.fromkeys(p[0] for p in r.pubs)


def _put(h, r, den):
    i = _idx(h)
    for sym in _syms(r):
        i.setdefault((den, sym), []).append(r)


def _cut(h, r, den):
    i = _idx(h)
    for sym in _syms(r):
        lst = i.get((den, sym))
        if not lst:
            continue
        for n, x in enumerate(lst):
            if x is r:
                del lst[n]
                break


def joined(h, r):
    _put(h, r, view.den(h, r))


def parted(h, r):
    _cut(h, r, view.den(h, r))


def moved(h, r, was):
    """A publication has just been made public: it leaves its old bucket for the public one.

    Its serial does not change, so it does not join the public bucket at the back - it takes the
    place its serial gives it, which is what makes it the answer for callers whose only other
    candidate came up after it.
    """
    _cut(h, r, was)
    i = _idx(h)
    for sym in _syms(r):
        lst = i.setdefault((None, sym), [])
        lo, hi = 0, len(lst)
        while lo < hi:
            mid = (lo + hi) // 2
            if lst[mid].at < r.at:
                lo = mid + 1
            else:
                hi = mid
        lst.insert(lo, r)


def find(h, caller, sym):
    i = _idx(h)
    best = None
    for key in view.keys(h, caller):
        lst = i.get((key, sym))
        if lst and (best is None or lst[0].at < best.at):
            best = lst[0]
    return best
PYEOF

cat > /app/link/site.py <<'PYEOF'
from link import pick
from reg import say


def reach(h, r, sym, out):
    if not r.live:
        return
    u = r.uses.get(sym)
    if u is None:
        t = pick.find(h, r, sym)
        if t is None:
            say.miss(out, r.name, sym)
            return
        r.uses[sym] = (t, t.at)
        say.ran(out, r.name, sym, t.name)
        return
    t, at = u
    if t.live and t.at == at:
        say.ran(out, r.name, sym, t.name)
    else:
        say.dead(out, r.name, sym)
PYEOF

cat > /app/link/want.py <<'PYEOF'
from reg import hold


def _owed(h):
    d = getattr(h, "owed", None)
    if d is None:
        d = h.owed = {}
    return d


def _hard(r):
    return dict.fromkeys(other for other, kind in r.needs if kind)


def joined(h, r):
    owed = _owed(h)
    for name in _hard(r):
        owed[name] = owed.get(name, 0) + 1


def parted(h, r):
    """r has gone down. Give back what it was holding, and name whatever that frees."""
    owed = _owed(h)
    freed = []
    for name in _hard(r):
        left = owed.get(name, 0) - 1
        owed[name] = left
        if left <= 0:
            freed.append(name)
    return freed


def wanted(h, r):
    return hold.held(h, r.name) > 0 or _owed(h).get(r.name, 0) > 0
PYEOF

cat > /app/link/drop.py <<'PYEOF'
"""Releasing a hold, and the cascade that follows it.

The rule is that the last unwanted unit in publication order goes down, that the retirement is
applied before the next candidate is chosen, and that this repeats until a pass finds nothing.
Read as written it is a scan of the live set per retirement, which a teardown of a deep forest
turns into a quadratic walk.

What replaces it is a queue of units that may have stopped being wanted, kept in reverse
publication order and consulted lazily. A unit joins it in exactly three situations: it is
published with nothing wanting it, the last live unit that needed it goes down, or the hold it
was standing on is given back. Nothing else can change the answer, so nothing else needs to be
watched, and a unit found still wanted when its turn comes is simply dropped from the queue -
whatever makes it unwanted later will put it back.

The queue is keyed by the publication serial rather than by position, and that is not a
convenience. Positions shift as units are spliced out, and a dependency that retired and came
back sits *after* the dependent that needs it, so a cascade can expose a candidate later in the
order than the unit that exposed it. A structure that assumes candidates only ever appear
earlier is right on every ordinary teardown and wrong there.
"""
import heapq

from link import pick, want
from reg import hold, order, say, tab


def _queue(h):
    q = getattr(h, "loose", None)
    if q is None:
        q = h.loose = []
    return q


def note(h, r):
    heapq.heappush(_queue(h), (r.at, r.at, r.name))


def let(h, name, out):
    r = tab.get(h, name)
    if not r.live or hold.held(h, name) <= 0:
        return
    hold.give(h, name)
    note(h, r)
    _sweep(h, out)


def _sweep(h, out):
    q = _queue(h)
    while q:
        _key, at, name = heapq.heappop(q)
        go = h.units.get(name)
        if go is None or not go.live or go.at != at or want.wanted(h, go):
            continue
        for freed in want.parted(h, go):
            rec = h.units.get(freed)
            if rec is not None and rec.live:
                note(h, rec)
        go.live = False
        order.drop(h, go)
        pick.parted(h, go)
        say.down(out, go.name)
PYEOF

