def cycle(h):
    return [], [], []
