"""Ageing and promotion.

A nursery object that came through a collection gets a year older, and at `PROMOTE_AGE` it moves
to old space. Being kept so a finalizer can run is not coming through a collection: those objects
do not age, so an object waiting on its finalizer cannot promote out of the nursery while it
waits. If its finalizer stores it back somewhere live it starts ageing again from the next
collection, like anything else that survived.

A pinned object still ages but cannot move, so it stays in the nursery until the pin comes off.
It promotes at the first later collection it survives if its age has reached the threshold.

Promotion is another old-to-nursery write-barrier boundary. An object can already have fields
when it moves, so every field that still names a nursery object is recorded at that point. Later
writes into the old object are recorded by `mem/rset.py` in the ordinary way.

Promotion is also the only thing that takes an object out of the nursery, so it is what has to
take it out of `h.young`. Leave it there and every later minor collection treats an old object as
its own to trace and to release.
"""
from mem import heap, rset


def promote(h, seen, held):
    moved = []
    for i in sorted(h.young):
        o = h.objs[i]
        if i not in seen or i in held:
            continue
        o.age += 1
        if o.age >= heap.PROMOTE_AGE and o.pins == 0:
            o.space = heap.OLD
            h.young.discard(i)
            for fld, val in sorted(o.flds.items()):
                rset.note(h, i, fld, val)
            moved.append(i)
    return moved
