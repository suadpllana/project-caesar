"""Objects kept only so a queued finalizer can run, and the queue itself.

The queue is settled against what the collection reached, before any of this keeping is granted.
Settle it afterwards and an object reachable only from another finalizable object looks like it
is being kept rather than like garbage, and never gets finalized at all.

What a queued finalizer keeps is its object and everything that object reaches, by the same walk
and the same pair rule, blocked from anything already reached so the two sets stay apart. They
have to stay apart: weak clearing and promotion both ask about the first set, and an object kept
only to run a finalizer is in neither.

`h.done` records the finalizers that have run, and it records them by serial because a number
outlives the object that had it. A fresh object standing where a finalized one stood has not been
finalized, so testing the number here retires a finalizer the runtime never ran.

Scope follows the collection kind. A minor collection can only queue and only keep nursery
objects; an old object with an unrun finalizer is not garbage yet, because nothing this
collection did could show that it was. `h.young` is the nursery, so the minor scope is that set
rather than a pass over the whole heap - which is the difference between a minor collection
costing what the nursery costs and costing what the heap costs.
"""
from col import scan
from mem import heap


def _scope(h, full):
    return sorted(h.objs) if full else sorted(h.young)


def settle(h, seen, full):
    objs = h.objs
    queued = set(h.queue)
    fresh = [i for i in _scope(h, full)
             if i not in seen and objs[i].fin is not None
             and objs[i].ser not in h.done and i not in queued]

    start = [i for i in h.queue if i in objs] + fresh
    if not full:
        start = [i for i in start if objs[i].space == heap.NURSERY]
    held = scan.reach(h, start, full, frozenset(seen)) if start else set()
    return fresh, held
