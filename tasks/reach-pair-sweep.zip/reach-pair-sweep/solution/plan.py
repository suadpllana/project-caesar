"""Which objects start the walk, which differs by collection kind.

A full collection starts from everything named: frame slots, the global table, the handle stack.
A minor collection starts from the nursery ones among those - old objects are live by assumption
and are never traced - and must add the nursery objects reachable from old space, which is the
only reason the remembered set exists.

The remembered set is a hint, not an answer. `mem/rset.py` records a (source, field, value)
triple when a field of an OLD object is given a nursery value, and never revisits it afterwards.
The value in the triple is the value the field had at the moment of the write, and nothing keeps
it current: overwrite the field and the old triple stays, naming an object nothing points at any
more. So the triple says where to look and the field's value now is the answer - taking the
recorded value keeps dead objects alive, and ignoring the set loses live ones.

Nothing else prunes it either. `rset.forget` only drops entries whose source has been released,
so every store into an old field leaves a triple behind for good: write the same field a thousand
times and a thousand triples answer the same question about the same field. Two entries sharing a
source and a field are the same entry, because the recorded value is not what is read. One of
them is kept and the rest go. An entry whose field has stopped naming a nursery object goes too -
it cannot become interesting again on its own, since any later store that would make it so runs
through the barrier and records itself. That is what keeps a minor collection costing what the
nursery costs rather than what the program's whole history of stores costs.
"""
from mem import heap, roots as rootsrc


def roots(h, full):
    named = rootsrc.named(h)
    if full:
        return sorted(set(named))

    objs = h.objs
    out = [i for i in named if objs[i].space == heap.NURSERY]
    live = {}
    for entry in h.rset:
        src, fld, was = entry
        if (src, fld) in live:
            continue
        owner = objs.get(src)
        val = owner.flds.get(fld) if owner is not None else None
        cur = objs.get(val) if val is not None else None
        if cur is None or cur.space != heap.NURSERY:
            continue
        live[(src, fld)] = entry
        out.append(val)
    h.rset = set(live.values())
    return sorted(set(out))
