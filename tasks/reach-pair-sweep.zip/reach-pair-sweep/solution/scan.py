"""The reachability walk, and the pair table folded into it.

A pair's value is reached only while that pair's key is reached, and a value that arrives can be
some other pair's key, so this is a fixed point rather than a sweep. The table is indexed by key
so each pair is followed the moment its key arrives and never looked at again: a pair can only
newly fire when its key first enters the set, and a key enters once. Sweeping the whole table
until a sweep adds nothing settles one link per sweep on a table written back to front.

The minor case is not the full case with a filter on the end. Only nursery objects join the set,
because old objects are not traced at all - but an old object is live for the whole of a minor
collection, so a pair keyed on one is ready before the walk starts and stays ready. Those values
seed the walk. Treating an old key as unreached loses the value; letting old objects into the set
makes them look collectable.
"""
from mem import heap, tables


def reach(h, start, full, barred):
    by = tables.by_key(h)
    stack = list(start)
    if not full:
        for k, vs in by.items():
            if k in h.objs and h.objs[k].space == heap.OLD:
                stack.extend(vs)

    seen = set()
    while stack:
        i = stack.pop()
        if i in seen or i in barred or i not in h.objs:
            continue
        if not full and h.objs[i].space == heap.OLD:
            continue
        seen.add(i)
        for v in h.objs[i].flds.values():
            if v is not None:
                stack.append(v)
        for v in by.get(i, ()):
            stack.append(v)
    return seen
