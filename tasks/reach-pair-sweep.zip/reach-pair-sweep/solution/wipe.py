"""Weak clearing, and what is released.

A weak reference clears when its referent cannot be reached. Being kept so a finalizer can run is
not being reached, so a reference to an object in that state clears while the object is still
there. Once cleared it stays cleared, whatever happens to the referent afterwards.

A minor collection has nothing to say about old space. It did not trace it and could not have
shown an old object unreachable, so a reference whose referent is old is left exactly as it is -
neither cleared nor examined. Clearing those on a minor collection is the mistake that empties a
weak table for objects that were never in danger.

Release is scoped the same way the queue is: everything for a full collection, the nursery alone
for a minor one, and the nursery is `h.young`.
"""
from mem import heap


def wipe(h, seen, full):
    out = []
    for name in sorted(h.weak):
        w = h.weak[name]
        if w.wiped:
            continue
        tgt = w.tgt
        if not full:
            if tgt not in h.objs or h.objs[tgt].space != heap.NURSERY:
                continue
        if tgt not in seen:
            w.wiped = True
            out.append(name)
    return out


def release(h, seen, held, full):
    scope = sorted(h.objs) if full else sorted(h.young)
    return [i for i in scope if i not in seen and i not in held]
