import heapq
from collections import deque

from eng import hand, take


class Frame:
    """What a whole order's execution may have to give back, taken at entry.

    Queue references are copied, so restoration keeps the order records the driver
    indexes by id, and only the values an execution actually changes are saved, into
    every frame open at the time. Two things are not given back, and the frame records
    them instead, at any depth: what fired, which has left the parked set, and what was
    pulled for `same`, which has left the book if it was standing when the frame opened.
    The failure path re-announces both and re-runs the first.
    """

    def __init__(self, st):
        self.last = st.last
        self.orders = {}
        self.sides = []
        for side in (st.bk.b, st.bk.s):
            levels = {px: deque(q) for px, q in side.lv.items()}
            self.sides.append((side, levels, list(side.pq)))
        self.pending = deque(st.pend)
        self.fired = []
        self.pulled = []

    def restore(self, st):
        st.last = self.last
        for order, values in self.orders.items():
            order.rem, order.shn, order.live = values
        for side, levels, prices in self.sides:
            side.lv = levels
            side.pq = prices
        st.pend = self.pending

    def standing(self, order):
        """Was the order on the book when this frame opened? Its first touch says."""
        return self.orders[order][2]


class Tape:
    """Uncommitted rows never reach the externally observed emitter."""

    def __init__(self):
        self.rows = []

    def row(self, *cells):
        self.rows.append(cells)


def frames(st):
    if not hasattr(st, "frames"):
        st.frames = []
    return st.frames


def touch(st, order):
    for frame in frames(st):
        if order not in frame.orders:
            frame.orders[order] = (order.rem, order.shn, order.live)


def fired(st, seq, order):
    for frame in frames(st):
        frame.fired.append((seq, order))


def pulled(st, order):
    for frame in frames(st):
        frame.pulled.append(order)


def room(st, o):
    """Quantity a walk could take right now, read without touching anything.

    Retained for the frozen interface. Admission never consults it: a walk that would
    fill nothing can still pull the participant's own orders off the book, and those
    cancellations stand, so there is no count that says a whole order may be refused
    without walking.
    """
    opp = st.bk.opp(o.side)
    sign = 1 if o.side == "b" else -1
    got = 0
    last = st.last
    pq = list(opp.pq)
    while pq and got < o.rem:
        px = sign * heapq.heappop(pq)
        q = opp.lv.get(px)
        if q is None:
            continue
        body = [r for r in q if r.live]
        if not body:
            continue
        if o.px is not None and sign * (px - o.px) > 0:
            break
        if abs(px - last) > st.cap:
            break
        here = 0
        for r in body:
            if not hand.blocks(o, r):
                here += r.rem
        if here:
            last = px
            got += here
    return got


def admit(st, o, out):
    frame = Frame(st)
    frames(st).append(frame)
    tape = Tape()
    take.walk(st, o, tape)
    frames(st).pop()
    if o.rem <= 0:
        for row in tape.rows:
            out.row(*row)
        return
    frame.restore(st)
    gone = []
    for order in frame.pulled:
        if frame.standing(order) and order not in gone:
            order.live = False
            gone.append(order)
    out.row("pul", o.oid, "whole")
    for order in gone:
        out.row("pul", order.oid, "same")
    again = [order for _, order in sorted(frame.fired, key=lambda x: x[0])]
    for order in again:
        out.row("trp", order.oid)
    if st.pace == "fill":
        from mkt.drv import submit
        for order in again:
            submit(st, order, out)
    else:
        st.pend.extend(again)
