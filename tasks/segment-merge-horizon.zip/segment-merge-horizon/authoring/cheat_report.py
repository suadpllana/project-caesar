#!/usr/bin/env python3
"""Which assertion catches each cheat, and on which scenario.

A cheat scoring 0 proves nothing on its own. It has to fail on the axis it was aimed at: a
work-accounting cheat that dies on a NameError, or a value cheat that is caught by the
lifecycle trace, has been rejected by nothing and the mistake it was named for is still
unmeasured. This prints the failing tests so that can be read rather than assumed.

Usage:
    python3 authoring/cheat_report.py [name ...]
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

TASK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TASK / "authoring"))

import trial  # noqa: E402

FAIL = re.compile(r"^FAILED (?:.*::)?(\w+)\[?([^\]]*)\]?", re.M)


def summarise(tail: str) -> str:
    hits = FAIL.findall(tail)
    if not hits:
        return "no FAILED lines - check that it ran at all"
    axes = {}
    for test, case in hits:
        axes.setdefault(test, []).append(case)
    out = []
    for test, cases in sorted(axes.items(), key=lambda kv: -len(kv[1])):
        out.append("%s x%d (%s)" % (test, len(cases), cases[0] if cases[0] else "-"))
    return "; ".join(out[:3])


def main(argv: list[str]) -> int:
    wanted = set(argv[1:])
    rows = []
    for d in sorted((TASK / "authoring" / "cheatsrc").glob("*")):
        if not d.is_dir() or (wanted and d.name not in wanted):
            continue
        reward, tail = trial.grade("authoring/cheatsrc/" + d.name)
        rows.append((d.name, reward, summarise(tail)))
    for name, reward, why in rows:
        flag = "    " if reward == 0 else "!!! "
        print("%s%-24s reward=%d  %s" % (flag, name, reward, why))
    bad = [r for r in rows if r[1] != 0]
    print("\n%d of %d scored 1 and should not have" % (len(bad), len(rows)))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
