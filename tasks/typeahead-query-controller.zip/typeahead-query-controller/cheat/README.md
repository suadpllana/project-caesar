# Cheating attempts considered

Each of these was tried against the verifier while building the task. None
is executed by the pipeline; they are recorded so the defences are explicit.

## 0. Execute code via the build config (vite.config.ts RCE)

The strongest attack: Vite evaluates `vite.config.ts` as code when the dev
server starts. If the verifier served the agent's own config, an agent could
inject a plugin that runs arbitrary code inside the verifier and forges
`reward.txt`. See `cheat/vite_config_rce.ts`.

**Rejected by three independent layers**, any one sufficient:

1. `test.sh` never serves the agent's `vite.config.ts`, `tsconfig.json` or
   `package.json` -- it overlays the pristine copies baked into the verifier
   image and deletes any config-shaped files dropped into `src/`. The agent's
   config is never evaluated.
2. The dev server runs as the unprivileged `verifier` user (`setpriv`), and
   `/logs/verifier` is root-owned mode 0700. Code that does execute cannot
   read, write or replace the reward file (EACCES).
3. `run_conformance.js` hashes `vite.config.ts`, `tsconfig.json` and
   `package.json` against pristine copies before any scenario runs; a mismatch
   fails `test_protected_files_unmodified` with zero scenarios executed.

Additionally, all agent-derived processes are killed and the reward is
re-asserted to `0` before grading, so a self-daemonizing plugin cannot win a
late race against the verdict.

## 1. Rewrite the transport so races cannot happen

The most direct exploit: edit `src/transport.ts` so `settleIgnoringAbort`
behaves like `settle`, or so aborted requests never resolve. Every ordering
scenario then passes with the original buggy controller.

**Rejected by:** the driver hashes `src/types.ts`, `src/transport.ts`,
`src/main.ts` and `public/index.html` against pristine copies baked into the
verifier image before any scenario runs, and `test_protected_files_unmodified`
fails the whole run on a mismatch. The pristine copies live in the verifier
image, which the agent never sees and cannot write to.

## 2. Fake the harness

Replace `src/main.ts` so `window.__harness.controller` is a stub that
returns whatever state the scenarios want, ignoring the real controller.

**Rejected by:** same integrity check -- `main.ts` is protected.

## 2b. Substitute the harness without touching a protected file

Attacks 1 and 2 are blocked by hashes on the files that *define* the harness.
Neither hash decided where the suite *found* it. Every scenario opened with
`const h = window.__harness`, and two routes reach that global ahead of the
suite without modifying anything hashed:

- `cheat/harness_override_index.html`. Vite's root is `public/`, so
  `public/index.html` is the document that boots the module graph. Module
  scripts run in document order, so a second `<script type="module">` after
  the `main.ts` tag executes *after* the harness is installed and simply
  reassigns `window.__harness` to a compliant reimplementation written inline.
  `public/` was an uploaded artifact, was copied verbatim by `test.sh`, was
  absent from `PROTECTED`, and had no pristine copy.
- `cheat/harness_preempt_controller.ts`. The same payload with no file outside
  the declared artifact. `main.ts` imports `controller.ts`, so the agent's
  module is evaluated *before* `main.ts` assigns anything; installing an
  accessor with `Object.defineProperty(window, "__harness", { set() {} })`
  makes that assignment a silent no-op and the suite reads the fake.

Both scored **13 of 13 with `src/controller.ts` left exactly as shipped**, so
this was a full bypass, not a partial one. Measured on 2026-08-14.

**Rejected by three independent layers**, added together because the second
route proves that pinning the page shell alone is not enough:

1. The scenarios no longer read a global. The prelude takes the harness from
   the module namespace of `main.ts` (`(await import("/src/main.ts")).harness`).
   A module namespace object is sealed and `main.ts` is hashed, so nothing
   else in the graph can substitute what `h` refers to, and `import()` is
   syntax rather than a global lookup, so it cannot be patched out either.
   This is what kills the `defineProperty` route, which no hash can reach.
2. `public/` is served from the verifier image, exactly like `tsconfig.json`,
   `vite.config.ts` and `package.json`. The agent's copy is never served.
3. `public/index.html` is in `PROTECTED` and has a pristine copy under
   `tests/pristine/public/`, so a failure of layer 2 still fails the run
   before any scenario executes.

`/app/public` was also dropped from `artifacts` in `task.toml`: the page shell
is not a deliverable, so it is no longer uploaded at all.

## 3. Neutralise the scenarios

Delete scenarios, rename their ids, or make `run_conformance.js` report
`pass: true`.

**Rejected by:** the tests are baked into the verifier image with
`COPY . /tests/` and are not reachable from the environment container at all.
`REQUIRED_IDS` in `test_conformance.py` is asserted independently, so a
report that omits or renames a scenario fails `test_all_scenarios_ran`.

## 4. Write the reward file directly

Have the agent create `/logs/verifier/reward.txt` containing `1`.

**Rejected by:** the verifier runs in a separate container after the
environment is torn down, and `test.sh` unconditionally overwrites the file
with `0` before grading. Only a clean pytest exit rewrites it to `1`.

## 5. Suppress everything

Notice that several scenarios check that bad states are never emitted, and
"solve" them by making the controller emit nothing at all, or never leave
`loading`.

**Rejected by:** `r4b`, `r5`, `r7b` and `r8` require positive outcomes --
the authoritative result must arrive, a cached query must be served with the
right items, a real transport failure must surface as `status: "error"`, and
a typing burst must settle on the final query. A controller that stays silent
fails all four. `r7_emit_snapshot` additionally requires that all four
subscribers are notified exactly once.

## 6. Hardcode the fixtures

Detect the specific query strings used by the tests (`"ca"`, `"car"`,
`"carbon"`, …) and return canned results.

**Partially open, and deliberately so.** The scenarios use several disjoint
query families and assert on transport call counts and provisional flags as
well as payloads, so a lookup table has to reproduce the caching and
continuity *behaviour* rather than just the strings -- at which point it is
doing the real work in a fragile way. `see cheat/hardcode_attempt.ts` for how
far this gets: it fails `r8` because the burst asserts the payload came from
the transport for the final query.
