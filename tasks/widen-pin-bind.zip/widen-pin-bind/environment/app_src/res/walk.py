from res import best, cost, pick, pin, spec


class State:
    def __init__(self, prog):
        self.prog = prog
        self.pins = {}
        self.sum = 0
        self.why = "none"


def new(prog):
    return State(prog)


def total(state):
    return state.sum


def ask(state, node):
    state.why = "none"
    binds = []
    made = []
    gives = walk(state, node, None, binds, made)
    if gives is None:
        return spec.Result(state.why, None, [], [])
    return spec.Result("bind", gives, binds, made)


def walk(state, node, expected, binds, made):
    prog = state.prog
    stands = []
    for arg in node.args:
        if arg.args is None:
            stands.append(prog.vals[arg.name])
        else:
            got = walk(state, arg, None, binds, made)
            if got is None:
                return None
            stands.append(got)
    rows = []
    keep = []
    for ent in pick.cands(prog, node.name, len(node.args)):
        row = fit(state, ent, stands, made)
        if row is None:
            continue
        gives = pick.result(ent, state.pins.get(ent.idx))
        last = cost.result(prog, gives, expected)
        if last is None:
            continue
        rows.append(row + [last])
        keep.append((ent, gives))
    if not rows:
        state.why = "none"
        return None
    which = best.winner(rows)
    if which is None:
        state.why = "amb"
        return None
    ent, gives = keep[which]
    binds.append((node.site, ent.idx))
    state.sum += sum(rows[which])
    return gives


def fit(state, ent, stands, made):
    prog = state.prog
    settled = state.pins.get(ent.idx) if ent.opened else None
    if ent.opened and settled is None:
        spots = pick.opens(ent)
        if not spots:
            return None
        settled = pin.settle(prog, [stands[i] for i in spots])
        if settled is None or not pick.in_bound(prog, ent, settled):
            return None
        state.pins[ent.idx] = settled
        made.append((ent.idx, settled))
    row = []
    for asked, was in zip(pick.slots(ent, settled), stands):
        step = cost.slot(prog, was, asked)
        if step is None:
            return None
        row.append(step)
    return row
